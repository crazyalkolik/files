. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/L4UD1/logs/MaskD1PDBs_$DATE.log


echo "Masking Application PDB L4U_S"

sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/MaskPDB_L4U_S.sql >> $LOG

echo " ################# APPLICATON PDB L4U_S ################# " > $MASKLOG

cat /home/oracle/scripts/L4UD1/logs/maskapppdbl4u_s_$DATE.log >> $MASKLOG
cat /home/oracle/scripts/L4UD1/logs/maskapppdbl4u_s_$DATE.log >> $LOG


echo "Masking Application PDB L4U_S is completed Successfully"
