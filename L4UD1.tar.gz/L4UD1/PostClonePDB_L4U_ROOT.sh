. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/CreateD1PDBs_$DATE.log
export PCLOG=/home/oracle/scripts/L4UD1/logs/PostClonePDB_L4U_ROOT_$DATE.log


echo "Post Clone Applicatipon PDB L4U_ROOT"

sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/PostClonePDB_L4U_ROOT.sql >> $LOG

echo " ################# APPLICATON PDB L4U_ROOT ################# " > $PCLOG

cat /home/oracle/scripts/L4UD1/logs/postclonedbl4u_root_$DATE.log >> $PCLOG
cat /home/oracle/scripts/L4UD1/logs/postclonedbl4u_root_$DATE.log >> $LOG


echo "Post Clone Application PDB L4U_ROOT is completed Successfully"


