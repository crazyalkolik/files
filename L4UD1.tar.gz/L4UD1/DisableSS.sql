SET TERMOUT OFF

spool /home/oracle/scripts/L4UD1/logs/DisableSS_$DATE.log

startup mount force;
select status, instance_name, database_role,open_mode from v$database, v$instance;
select flashback_on from v$database;
alter database convert to physical standby;
alter database flashback off;
select status, instance_name, database_role,open_mode from v$database, v$instance;
select flashback_on from v$database;
alter database recover managed standby database disconnect from session;

spool off
exit
