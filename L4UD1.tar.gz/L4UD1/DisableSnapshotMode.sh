############ Cihan Gedik
############ 28.08.2021
############ Version 1
############ This Scripts turn physical Standby to Snapshot Standby Mode

. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/L4UD1_SS_STBY_DISABLE_$DATE.log


############# DISABLE SNAPSHOT STANDBY


echo " ######### DISABLE SNAPSHOT STANDBY ###########
" > $LOG 

sh /home/oracle/scripts/L4UD1/DisableSS.sh > $LOG


echo "

######### SNAPSHOT STANDBY is DISABLED ########### " >> $LOG

echo "


" >> $LOG


tail -10000 /u01/app/oracle/diag/rdbms/lfud1/LFUD1/trace/alert_LFUD1.log > /home/oracle/scripts/L4UD1/logs/alert_L4UD1_DISABLE_$DATE.log


tar -cvzf /home/oracle/scripts/L4UD1/logs/DisableSS_$DATE.tar.gz /home/oracle/scripts/L4UD1/logs/*
rm -rf /home/oracle/scripts/L4UD1/logs/*.log
