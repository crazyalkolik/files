. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/L4UD1/logs/MaskD1PDBs_$DATE.log


echo "Masking Application PDB L4U_H"

sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/MaskPDB_L4U_H.sql >> $LOG

echo " ################# APPLICATON PDB L4U_H ################# " > $MASKLOG

cat /home/oracle/scripts/L4UD1/logs/maskapppdbl4u_h_$DATE.log >> $MASKLOG
cat /home/oracle/scripts/L4UD1/logs/maskapppdbl4u_h_$DATE.log >> $LOG


echo "Masking Application PDB L4U_H is completed Successfully"
