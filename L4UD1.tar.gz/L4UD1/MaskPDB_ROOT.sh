. /home/oracle/.L4UD1.env
		
export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/L4UD1/logs/MaskD1PDBs_$DATE.log


echo "Masking Application PDB ROOT"

sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/MaskPDB_ROOT.sql >> $LOG

echo " ################# L4U APPLICATON PDB ROOT LOG ################# " > $MASKLOG

cat /home/oracle/scripts/L4UD1/logs/maskapppdbroot_$DATE.log >> $MASKLOG
cat /home/oracle/scripts/L4UD1/logs/maskapppdbroot_$DATE.log >> $LOG


echo "Masking Application PDB ROOT is completed Successfully"
