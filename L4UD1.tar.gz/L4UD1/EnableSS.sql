SET TERMOUT OFF

spool /home/oracle/scripts/L4UD1/logs/EnableSS_$DATE.log


alter database recover managed standby database cancel;
select flashback_on from v$database;
alter database flashback on;
shu immediate;
startup mount;
select flashback_on from v$database;
select status, instance_name, database_role,open_mode from v$database, v$instance;
alter database convert to snapshot standby;
shu immediate;
startup;
alter pluggable database all open;
show pdbs;
startup force;
alter system set "_no_snapshot_root_clone" = true scope = both;
alter pluggable database all open;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;

alter session set container=L4U_S

ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE TEMP ADD TEMPFILE SIZE 1G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
alter pluggable database L4U_ROOT$SEED close;
select status, instance_name, database_role,open_mode from v$database, v$instance;
ALTER SYSTEM SET LOCAL_LISTENER='(ADDRESS=(PROTOCOl=TCP)(HOST=istsl75l4u1t.tr.xcd.net.intra)(PORT=1522))' SCOPE=BOTH;

spool off
exit
