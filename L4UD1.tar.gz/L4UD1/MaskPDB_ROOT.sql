set echo on
set feed on
set time on
set timing on
set lines 300
set trims on
set serveroutput on size unlimited

spool /home/oracle/scripts/L4UD1/logs/maskapppdbroot_$DATE.log

alter session set container=L4U_ROOT;
					
/*
--Bu kýpplication containerda farklýtilmeli. Nasýýýumadýç kapattý yi noarchive moda alýabilirsin.
  ALTER TABLE AGITO.T_MERNISARA NOLOGGING;
*/
  ALTER TRIGGER AGITO.TRG_MERNISARA_LOG DISABLE;
 
alter session enable parallel dml;
 
/* execute on ROOT */
Update /*+ PARALLEL (8)*/ AGITO.T_MERNISARA Set 
      AD    = DBMS_RANDOM.STRING('U',nvl(length(ad),0)),
      SOYAD = DBMS_RANDOM.STRING('U',nvl(length(soyad),0)),
      KIZLIKSOYAD = DBMS_RANDOM.STRING('U',nvl(length(kizliksoyad),0)),
      KIMLIKNO = SUBSTR(kimlikno,1,2)||MOD(SUBSTR(kimlikno,3,1)+5,10)||SUBSTR(kimlikno,4,2)||MOD(SUBSTR(kimlikno,6,2)+68,100)||SUBSTR(kimlikno,8),
      ANNEADI = DBMS_RANDOM.STRING('U',nvl(length(anneadi),0)),
      BABAADI = DBMS_RANDOM.STRING('U',nvl(length(babaadi),0)),
      DOGTAR = TO_DATE(TRUNC(DBMS_RANDOM.VALUE(TO_CHAR(date '2000-01-01', 'J'), TO_CHAR(date '2199-12-31', 'J'))),'J'),
      MEDENIHAL = DBMS_RANDOM.STRING('U',nvl(length(medenihal),0)),
      IKAMETADRES = DBMS_RANDOM.STRING('X',nvl(length(ikametadres),0)),
      IKAMETADRESILKOD = DBMS_RANDOM.STRING('X',nvl(length(ikametadresilkod),0)),
      IKAMETADRESILAD = DBMS_RANDOM.STRING('X',nvl(length(ikametadresilad),0)),
      IKAMETADRESILCE = DBMS_RANDOM.STRING('X',nvl(length(ikametadresilce),0)),
      IKAMETADRESILCEAD = DBMS_RANDOM.STRING('X',nvl(length(ikametadresilcead),0)),
      IKAMETADRESMAHALLEKOD = decode(ikametadresmahallekod,null, null,312||(trunc(dbms_random.value(1000000, 9999999)))),
      IKAMETADRESMAHALLEAD = DBMS_RANDOM.STRING('X',nvl(length(ikametadresmahallead),0)),
      IKAMETADRESBINAADA = DBMS_RANDOM.STRING('X',nvl(length(ikametadresbinaada),0)),
      IKAMETADRESBINABLOKADI = DBMS_RANDOM.STRING('X',nvl(length(ikametadresbinablokadi),0)),
      IKAMETADRESBINAKODU = decode(ikametadresbinakodu,null, null,312||(trunc(dbms_random.value(1000000, 9999999)))),
      IKAMETADRESDISKAPINO = DBMS_RANDOM.STRING('X',nvl(length(ikametadresdiskapino),0)),
      IKAMETADRESICKAPINO = DBMS_RANDOM.STRING('X',nvl(length(ikametadresickapino),0));
COMMIT;

  ALTER TRIGGER AGITO.TRG_MERNISARA_LOG ENABLE;
 
 /*
  ALTER TABLE AGITO.T_MERNISARA LOGGING;
*/


spool off
exit
