. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/CreateD1PDBs_$DATE.log
export PCLOG=/home/oracle/scripts/L4UD1/logs/PostClonePDB_L4U_H_$DATE.log


echo "Post Clone Application PDB L4U_H"

sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/PostClonePDB_L4U_H.sql >> $LOG

echo " ################# APPLICATON PDB L4U_H ################# " > $PCLOG

cat /home/oracle/scripts/L4UD1/logs/postclonedbl4u_h_$DATE.log >> $PCLOG
cat /home/oracle/scripts/L4UD1/logs/postclonedbl4u_h_$DATE.log >> $LOG


echo "Post Clone Application PDB L4U_H is completed Successfully"
