set echo on
set feed on
set time on
set timing on
set lines 300
set trims on
set serveroutput on size unlimited

spool /home/oracle/scripts/L4UD1/logs/postclonedbl4u_h_$DATE.log

alter session set container=L4U_H;

/*
--Bu kýpplication containerda farklýtilmeli. Nasýýýumadýç kapattý yi noarchive modea alýabilirsin.
ALTER TABLE AGITO.T_PHONE NOLOGGING; 
ALTER TABLE AGITO.T_EMAIL NOLOGGING;
ALTER TABLE AGITO.T_ADRESLER NOLOGGING;
ALTER TABLE AGITO.T_PERKKART NOLOGGING;
ALTER TABLE AGITO.T_PERSONBANKA NOLOGGING;
ALTER TABLE AGITO.T_SIGORTALI NOLOGGING;  
*/
ALTER TRIGGER AGITO.TRG_PHONE_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_EMAIL_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_ADRESLER_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_PERKKART_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_PERSONBANKA_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_PERSON_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_SIGORTALI_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_PERSONEK_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_TEKLIFPERSON_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_KARALISTE_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_YENILEMEDETAYREVIZYON_LOG DISABLE;
ALTER TRIGGER AGITO.TRG_TAHSILATIADE_LOG DISABLE;

alter session enable parallel dml;

--run this script for each pdb(E/S/H)
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.222:8084/gatewayapp/services/paymentGateway?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'CardifPaymentGateway';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://day-1-l4u.tr.xcd.net.intra:7003/DocumentWebServiceFacade/DocumentWebServiceFacadeService?WSDL'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'createDocument';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://day-1-l4u.tr.xcd.net.intra:7003/DocumentWebServiceFacade/DocumentWebServiceFacadeService?WSDL'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'createNotificationDocument';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.219:9080/p8rest/document'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'documentManagementFileNet';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.222:9080/services/NotificationService?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'emailServiceCardif';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.142:7003/LPISRest/FtpProxyService?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'FtpProxyService';
/*update agtenteg.t_prm_wsc a
   set a.wsdl = ''
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'HAYMERFKCANLI';
update agtenteg.t_prm_wsc a
   set a.wsdl = ''
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'HAYMERFKTEST';*/
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://day-1-l4u.tr.xcd.net.intra:9096/identityCache/IdentityCacheService'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'identityCacheService';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.168/esb_l4u/MernisKisiSorgulaServices.svc?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'identitySearchMernisCardif';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.168/esb_l4u/KpsAileBireyServices.svc?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'identitySearchSbmCardif';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.168/esb_l4u/VknSorguServices.svc?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'identitySearchVknCardif';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.168/esb_l4u/HaymerIskurServices.svc?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'iskurCardif';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.198:8001/wslkumulrisk/wslkumulriskSoapHttpPort?WSDL'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'KumulRisk';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.182:8090/LG_cardiff?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'logoCardif';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.222:9080/services/PayBeeService?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'paybeeCardif';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.244:8762/auth'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'securins_auth';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.244:8762/securins'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'securins_auth_service';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.244:8090/securins'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'securins_service';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.222:9080/services/ShortenerWebService?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'Shortener';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.222:9080/services/NotificationService?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'smsServiceCardif';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://day-1-l4u.tr.xcd.net.intra:7003/AgitoWs/ServiceProxy?WSDL'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'SoapProxy';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://day-1-l4u.tr.xcd.net.intra:7048/AgitoWs/ServiceProxy?WSDL'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'SoapProxyTomcat';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'https://www.tcmb.gov.tr/kurlar/today.xml'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'tcmb_daily_currency';
update agtenteg.t_prm_wsc a
   set a.wsdl = 'http://10.170.146.168/esb_l4u/TebServices.svc?wsdl'
      ,a.username = ''
      ,a.password = ''
      ,a.walletpath = ''
      ,a.walletpassword = ''
      ,a.proxyaddress = ''
      ,a.proxyport = null
 where a.wscname = 'TEBDAILYTRANSFER';

update agtenteg.t_virtualposprm a
   set a.clientid = '400000100'
      ,a.userid = '4000237070admin'
      ,a.password = 'TEST_SANAL_POS_2020'
 where a.bankid = 32;
update agtenteg.t_virtualposprm a
   set a.clientid = '67905492'
      ,a.userid = 'paribas'
      ,a.password = 'Pos12345'
 where a.bankid = 67;
 
update agtprm.t_sysprm a
   set a.prmval = '[D-1 Ortamý]'
 where a.prmname = 'ENVIRONMENT';
update agtprm.t_sysprm a
   set a.prmval = 'WSPOLICEINS'
 where a.prmname = 'TEBDAILYTRANS_SRVID_147_USER';
update agtprm.t_sysprm a
   set a.prmval = '963852741'
 where a.prmname = 'TEBDAILYTRANS_SRVID_147_PWD';
update agtprm.t_sysprm a
   set a.prmval = 'WSSIGWPOL'
 where a.prmname = 'TEBDAILYTRANS_SRVID_991_USER';
update agtprm.t_sysprm a
   set a.prmval = '-Ws0rt!Bu1@sRt'
 where a.prmname = 'TEBDAILYTRANS_SRVID_991_PWD';
update agtprm.t_sysprm a
   set a.prmval = 'WSPOLMUT'
 where a.prmname = 'TEBDAILYTRANS_SRVID_974_USER';
update agtprm.t_sysprm a
   set a.prmval = '.P@cl!a16'
 where a.prmname = 'TEBDAILYTRANS_SRVID_974_PWD';
 
update agtprm.t_sysparam a
   set a.printserverhost = 'http://day-1-l4u.tr.xcd.net.intra:7003/LPISRest/api'
 where a.sirketad = 'CARDIF EMEKLILIK';

update agito.t_ftpparameter a
   set a.host = '10.170.146.220'
      ,a.port = 22
      ,a.username = 'off2on'
      ,a.password = 'A%2.b+C34-Fd'
      ,a.type = 'S'
 where a.connectionname = 'BULK_PRINTING_DATA_FTP';

BEGIN
  DBMS_NETWORK_ACL_ADMIN.CREATE_ACL(acl         => 'agitoservices.xml',
                                    description => 'Permission for access to all services on Agito',
                                    principal   => 'AGITO',
                                    is_grant    => TRUE,
                                    privilege   => 'resolve');
END;
/
begin
   DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl       => 'agitoservices.xml',
                                        principal => 'AGTENTEG',
                                        is_grant  => true,
                                        privilege => 'connect');  
   DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl       => 'agitoservices.xml',
                                        principal => 'AGTENTEG',
                                        is_grant  => true,
                                        privilege => 'resolve');  
   DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE(acl       => 'agitoservices.xml',
                                        principal => 'AGITO',
                                        is_grant  => true,
                                        privilege => 'connect');  
end;
/
begin
  DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL(acl => 'agitoservices.xml', host => 'day-1-l4u.tr.xcd.net.intra');
end;
/
begin
  --securins
  DBMS_NETWORK_ACL_ADMIN.ASSIGN_ACL(acl => 'agitoservices.xml', host => '10.170.146.244');
end;
/


commit;


ALTER TRIGGER AGITO.TRG_PERKKART_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_PERSON_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_PERSONBANKA_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_PERSONEK_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_PHONE_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_EMAIL_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_ADRESLER_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_SIGORTALI_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_TEKLIFPERSON_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_KARALISTE_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_YENILEMEDETAYREVIZYON_LOG ENABLE;
ALTER TRIGGER AGITO.TRG_TAHSILATIADE_LOG ENABLE;

/*
ALTER TABLE AGITO.T_PERSON LOGGING;
ALTER TABLE AGITO.T_PERSONEK LOGGING;
ALTER TABLE AGITO.T_PHONE LOGGING; 
ALTER TABLE AGITO.T_EMAIL LOGGING;
ALTER TABLE AGITO.T_ADRESLER LOGGING;
ALTER TABLE AGITO.T_PERKKART LOGGING;
ALTER TABLE AGITO.T_PERSONBANKA LOGGING;
ALTER TABLE AGITO.T_SIGORTALI LOGGING;
*/					
					
spool off
exit
