. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/L4UD1_SS_STBY_ENABLE_$DATE.log

sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/EnableSS.sql

cat /home/oracle/scripts/L4UD1/logs/EnableSS_$DATE.log >> $LOG
