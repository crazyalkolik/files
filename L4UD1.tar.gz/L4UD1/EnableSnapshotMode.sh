############ Cihan Gedik
############ 28.08.2021
############ Version 1
############ This Scripts turn physical Standby to Snapshot Standby Mode

. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/L4UD1_SS_STBY_ENABLE_$DATE.log
export MASKLOG=/home/oracle/scripts/L4UD1/logs/MaskD1PDBs_$DATE.log


############# ENABLE SNAPSHOT STANDBY


echo " ######### ENABLE SNAPSHOT STANDBY ###########
" > $LOG 

sh /home/oracle/scripts/L4UD1/EnableSS.sh > $LOG

echo "

######### SNAPSHOT STANDBY is ENABLED ########### " >> $LOG

echo "


" >> $LOG



############# MASK DATABASE

echo " ######### Masking Appplication PDB ROOT #######
" >> $LOG

sh /home/oracle/scripts/L4UD1/MaskPDB_ROOT.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/MaskPDB_L4U_H.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/MaskPDB_L4U_E.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/MaskPDB_L4U_S.sh >> $LOG 

echo " 
######### Masking Appplication PDB ROOT is completed Successfully  #########" >> $LOG



############# POST CLONE DATABASE

echo " ######### Post Clone Appplication PDBs #######
" >> $LOG

sh /home/oracle/scripts/L4UD1/PostClonePDB_L4U_ROOT.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/PostClonePDB_L4U_H.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/PostClonePDB_L4U_E.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/PostClonePDB_L4U_S.sh >> $LOG 

echo " 
######### Post Clone Appplication PDBs is completed Successfully  #########" >> $LOG


############# CREATE DEVELOPER USERS

echo " ######### Creating Developer Users #######
" >> $LOG

sh /home/oracle/scripts/L4UD1/CreateUsers.sh >> $LOG 

echo " 
######### Developer Users are completed Successfully  #########" >> $LOG


tail -10000 /u01/app/oracle/diag/rdbms/lfud1/L4UD1/trace/alert_L4UD1.log > /home/oracle/scripts/L4UD1/logs/alert_L4UD1_ENABLE_$DATE.log


tar -cvzf /home/oracle/scripts/L4UD1/logs/EnableSS_$DATE.tar.gz /home/oracle/scripts/L4UD1/logs/*
rm -rf /home/oracle/scripts/L4UD1/logs/*.log

