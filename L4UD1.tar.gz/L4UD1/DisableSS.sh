. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/L4UD1_SS_STBY_DISABLE_$DATE.log

sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/DisableSS.sql

cat /home/oracle/scripts/L4UD1/logs/DisableSS_$DATE.log >> $LOG

