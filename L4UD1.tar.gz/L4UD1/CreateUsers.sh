. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/CreateD1PDBs_$DATE.log


sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/CreateUsers.sql 

cat /home/oracle/scripts/L4UD1/logs/createusers_$DATE.log >> $LOG

