############ Cihan Gedik
############ 28.01.2021
############ Version 1


. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/L4UD1/logs/MaskD1PDBs_$DATE.log


############# POST CLONE DATABASE

echo " ######### Post Clone Appplication PDBs #######
" >> $LOG

sh /home/oracle/scripts/L4UD1/PostClonePDB_L4U_ROOT.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/PostClonePDB_L4U_H.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/PostClonePDB_L4U_E.sh >> $LOG 
sh /home/oracle/scripts/L4UD1/PostClonePDB_L4U_S.sh >> $LOG 

echo " 
######### Post Clone Appplication PDBs is completed Successfully  #########" >> $LOG



