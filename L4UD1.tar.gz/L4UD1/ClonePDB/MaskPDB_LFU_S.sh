. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/LFUD1/logs/MaskD1PDBs_$DATE.log


echo "Masking Application PDB LFU_S"

sqlplus -s / as sysdba @/home/oracle/scripts/LFUD1/MaskPDB_LFU_S.sql >> $LOG

echo " ################# APPLICATON PDB LFU_S ################# " > $MASKLOG

cat /home/oracle/scripts/LFUD1/logs/maskapppdblfu_s_$DATE.log >> $MASKLOG
cat /home/oracle/scripts/LFUD1/logs/maskapppdblfu_s_$DATE.log >> $LOG


echo "Masking Application PDB LFU_S is completed Successfully"
