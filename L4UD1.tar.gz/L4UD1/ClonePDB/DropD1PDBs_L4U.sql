SET TERMOUT OFF

spool /home/oracle/scripts/L4UD1/logs/droppdbs_$DATE.log

alter pluggable database all close;

drop pluggable database L4U_H including datafiles;
drop pluggable database L4U_E including datafiles;
drop pluggable database L4U_S including datafiles;
drop pluggable database L4U_ROOT$SEED including datafiles;
drop pluggable database L4U_ROOT including datafiles;

spool off 

exit

