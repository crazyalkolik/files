. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/LFUD1/logs/MaskD1PDBs_$DATE.log


echo "Masking Application PDB LFU_H"

sqlplus -s / as sysdba @/home/oracle/scripts/LFUD1/MaskPDB_LFU_H.sql >> $LOG

echo " ################# APPLICATON PDB LFU_H ################# " > $MASKLOG

cat /home/oracle/scripts/LFUD1/logs/maskapppdblfu_h_$DATE.log >> $MASKLOG
cat /home/oracle/scripts/LFUD1/logs/maskapppdblfu_h_$DATE.log >> $LOG


echo "Masking Application PDB LFU_H is completed Successfully"
