SET TERMOUT OFF
col instance_name format a20
col host_name format a20


spool /home/oracle/scripts/LFUD1/logs/restart_$DATE.log

select instance_name,host_name,version from v$instance;

startup force;

spool off
exit
