
spool /home/oracle/scripts/LFUD1/logs/created1pdbs_$DATE.log

create public database link clone_r connect to system identified by "C@rDif2021" using 'L4UMCDB';

alter session set db_create_file_dest='/data/datafiles/LFUD1/LFU_ROOT';
create pluggable database LFU_ROOT as application container from L4U_ROOT@clone_r;
alter pluggable database LFU_ROOT open;

alter session set container=LFU_ROOT;

alter trigger AGITOSVN.PLSQL_DDL_LOG disable;

create public database link clone_h connect to system identified by "C@rDif2021" using 'L4U_H';
create public database link clone_e connect to system identified by "C@rDif2021" using 'L4U_E';
create public database link clone_s connect to system identified by "C@rDif2021" using 'L4U_S';
create public database link clone_seed connect to system identified by "C@rDif2021" using 'L4U_ROOTSEED';


-----CREATE APPLICATION PDBs

#alter session set db_create_file_dest='/data/datafiles/LFUD1/PDBSEED';
#create pluggable database LFU_ROOT$SEED from L4U_ROOT$SEED@clone_seed parallel 8;

alter session set db_create_file_dest='/data/datafiles/LFUD1/LFU_H';
create pluggable database LFU_H from L4U_H@clone_h parallel 8;

alter session set db_create_file_dest='/data/datafiles/LFUD1/LFU_E';
create pluggable database LFU_E from L4U_E@clone_e parallel 8;

alter session set db_create_file_dest='/data/datafiles/LFUD1/LFU_S';
create pluggable database LFU_S from L4U_S@clone_s parallel 8;

alter pluggable database all open;

ALTER USER agito SET CONTAINER_DATA = (LFU_ROOT,LFU_E,LFU_H,LFU_S) CONTAINER=CURRENT;

-----CREATE AGITO USER

alter session set container=CDB$ROOT;

CREATE USER C##AGITOCO  IDENTIFIED BY aGito_2020 CONTAINER=ALL;
ALTER USER C##AGITOCO DEFAULT TABLESPACE USERS CONTAINER=CURRENT;
ALTER USER C##AGITOCO DEFAULT ROLE ALL;
GRANT CREATE SESSION TO C##AGITOCO;
GRANT UNLIMITED TABLESPACE TO C##AGITOCO;
GRANT READ, WRITE ON DIRECTORY DATA_PUMP_DIR TO C##AGITOCO CONTAINER=ALL;
GRANT EXECUTE ON SYS.UTL_RECOMP TO C##AGITOCO;


alter session set container=LFU_ROOT;

ALTER TRIGGER AGITOSVN.PLSQL_DDL_LOG ENABLE;

-----COMPILE INVALID OBJECTS

@$ORACLE_HOME/rdbms/admin/utlrp.sql

-----CHECK INVALID OBJECTS

select owner
	--,object_type
	,count(*) objects
	,count(decode(status,'INVALID',1,null)) as invalidObjects
	,count(decode(status,'INVALID',null,1)) as validObjects
from all_objects
where owner in ('AGITO','AGTENTEG','ATPRM','AGTCUSTPRM','AGTRULES','AGTPASS','AGTLOG','AGTTEST','AGITOSVN','GEV','HAYMER','HAYMERFK')
group by rollup(owner
--,object_type
);

spool off
exit
