############ Cihan Gedik
############ 28.01.2021
############ Version 1


. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/LFUD1/logs/MaskD1PDBs_$DATE.log


############# RESTART DATABASE

echo " ######### Database is Restarting ###########
" > $LOG 

sh /home/oracle/scripts/LFUD1/RestartDB.sh > $LOG

echo "
######### Database is Restarted ########### " >> $LOG

echo "


" >> $LOG

############# DROP DATABASE

echo " ######### PDBs are dropping ######### 
" >> $LOG

sh /home/oracle/scripts/LFUD1/DropD1PDBs.sh >> $LOG

echo " 
######## PDBs are dropped ######### " >> $LOG

