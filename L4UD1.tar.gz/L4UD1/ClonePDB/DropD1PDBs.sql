SET TERMOUT OFF

spool /home/oracle/scripts/LFUD1/logs/droppdbs_$DATE.log

alter pluggable database all close;

drop pluggable database LFU_H including datafiles;
drop pluggable database LFU_E including datafiles;
drop pluggable database LFU_S including datafiles;
drop pluggable database LFU_ROOT$SEED including datafiles;
drop pluggable database LFU_ROOT including datafiles;

spool off 

exit

