############ Cihan Gedik
############ 28.01.2021
############ Version 1


. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/LFUD1/logs/MaskD1PDBs_$DATE.log


############# POST CLONE DATABASE

echo " ######### Post Clone Appplication PDBs #######
" >> $LOG

sh /home/oracle/scripts/LFUD1/PostClonePDB_LFU_ROOT.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/PostClonePDB_LFU_H.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/PostClonePDB_LFU_E.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/PostClonePDB_LFU_S.sh >> $LOG 

echo " 
######### Post Clone Appplication PDBs is completed Successfully  #########" >> $LOG



