. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log


sqlplus -s / as sysdba @/home/oracle/scripts/LFUD1/CreateUsers.sql 

cat /home/oracle/scripts/LFUD1/logs/createusers_$DATE.log >> $LOG

