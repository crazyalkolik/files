############ Cihan Gedik
############ 28.01.2021
############ Version 1


. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log
export MASKLOG=/home/oracle/scripts/LFUD1/logs/MaskD1PDBs_$DATE.log


############# RESTART DATABASE

echo " ######### Database is Restarting ###########
" > $LOG 

sh /home/oracle/scripts/LFUD1/RestartDB.sh > $LOG

echo "
######### Database is Restarted ########### " >> $LOG

echo "


" >> $LOG

############# DROP DATABASE

echo " ######### PDBs are dropping ######### 
" >> $LOG

sh /home/oracle/scripts/LFUD1/DropD1PDBs.sh >> $LOG

echo " 
######## PDBs are dropped ######### " >> $LOG

echo "


" >> $LOG

############# CREATE DATABASE

echo " ######### Creating LFUD1 PDBs #########
" >> $LOG

sh /home/oracle/scripts/LFUD1/CreateD1PDBs.sh >> $LOG

echo " 
######### LFUD1 PDBs are Created  #########" >> $LOG


echo "


" >> $LOG


############# MASK DATABASE

echo " ######### Masking Appplication PDB ROOT #######
" >> $LOG

sh /home/oracle/scripts/LFUD1/MaskPDB_ROOT.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/MaskPDB_LFU_H.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/MaskPDB_LFU_E.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/MaskPDB_LFU_S.sh >> $LOG 

echo " 
######### Masking Appplication PDB ROOT is completed Successfully  #########" >> $LOG



############# POST CLONE DATABASE

echo " ######### Post Clone Appplication PDBs #######
" >> $LOG

sh /home/oracle/scripts/LFUD1/PostClonePDB_LFU_ROOT.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/PostClonePDB_LFU_H.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/PostClonePDB_LFU_E.sh >> $LOG 
sh /home/oracle/scripts/LFUD1/PostClonePDB_LFU_S.sh >> $LOG 

echo " 
######### Post Clone Appplication PDBs is completed Successfully  #########" >> $LOG


############# CREATE DEVELOPER USERS

echo " ######### Creating Developer Users #######
" >> $LOG

sh /home/oracle/scripts/LFUD1/CreateUsers.sh >> $LOG 

echo " 
######### Developer Users are completed Successfully  #########" >> $LOG

