#!/bin/bash
. /home/oracle/.LFUD1.env

{
rman log=/home/oracle/scripts/LFUD1/RMANdeleting.log << EOF
connect target /
set echo on;
delete noprompt archivelog all;
crosscheck archivelog all;
exit
EOF
}
