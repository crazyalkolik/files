. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log
export PCLOG=/home/oracle/scripts/LFUD1/logs/PostClonePDB_LFU_E_$DATE.log


echo "Post Clone Application PDB LFU_E"

sqlplus -s / as sysdba @/home/oracle/scripts/LFUD1/PostClonePDB_LFU_E.sql >> $LOG

echo " ################# APPLICATON PDB LFU_E ################# " > $PCLOG

cat /home/oracle/scripts/LFUD1/logs/postclonedblfu_e_$DATE.log >> $PCLOG
cat /home/oracle/scripts/LFUD1/logs/postclonedblfu_e_$DATE.log >> $LOG


echo "Post Clone Application PDB LFU_E is completed Successfully"
