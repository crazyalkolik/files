alter session set container=CDB$ROOT

ALTER USER c##orhant  ACCOUNT UNLOCK container=all; 
ALTER USER c##erguna  ACCOUNT UNLOCK container=all;
ALTER USER c##engino  ACCOUNT UNLOCK container=all;
ALTER USER c##mehmets ACCOUNT UNLOCK container=all;
ALTER USER c##onura   ACCOUNT UNLOCK container=all;
ALTER USER c##muratt  ACCOUNT UNLOCK container=all;
ALTER USER c##ozlems  ACCOUNT UNLOCK container=all;
ALTER USER c##emreb   ACCOUNT UNLOCK container=all;


