. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log
export PCLOG=/home/oracle/scripts/LFUD1/logs/PostClonePDB_LFU_S_$DATE.log


echo "Post Clone Application PDB LFU_S"

sqlplus -s / as sysdba @/home/oracle/scripts/LFUD1/PostClonePDB_LFU_S.sql >> $LOG

echo " ################# APPLICATON PDB LFU_S ################# " > $PCLOG

cat /home/oracle/scripts/LFUD1/logs/postclonedblfu_s_$DATE.log >> $PCLOG
cat /home/oracle/scripts/LFUD1/logs/postclonedblfu_s_$DATE.log >> $LOG


echo "Post Clone Application PDB LFU_S is completed Successfully"
