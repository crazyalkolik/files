. /home/oracle/.LFUD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/LFUD1/logs/CreateD1PDBs_$DATE.log
export PCLOG=/home/oracle/scripts/LFUD1/logs/PostClonePDB_LFU_ROOT_$DATE.log


echo "Post Clone Applicatipon PDB LFU_ROOT"

sqlplus -s / as sysdba @/home/oracle/scripts/LFUD1/PostClonePDB_LFU_ROOT.sql >> $LOG

echo " ################# APPLICATON PDB LFU_ROOT ################# " > $PCLOG

cat /home/oracle/scripts/LFUD1/logs/postclonedblfu_root_$DATE.log >> $PCLOG
cat /home/oracle/scripts/LFUD1/logs/postclonedblfu_root_$DATE.log >> $LOG


echo "Post Clone Application PDB LFU_ROOT is completed Successfully"


