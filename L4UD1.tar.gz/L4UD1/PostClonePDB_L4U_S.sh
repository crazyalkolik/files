. /home/oracle/.L4UD1.env

export DATE=$(date +"%d%m%Y")
export LOG=/home/oracle/scripts/L4UD1/logs/CreateD1PDBs_$DATE.log
export PCLOG=/home/oracle/scripts/L4UD1/logs/PostClonePDB_L4U_S_$DATE.log


echo "Post Clone Application PDB L4U_S"

sqlplus -s / as sysdba @/home/oracle/scripts/L4UD1/PostClonePDB_L4U_S.sql >> $LOG

echo " ################# APPLICATON PDB L4U_S ################# " > $PCLOG

cat /home/oracle/scripts/L4UD1/logs/postclonedbl4u_s_$DATE.log >> $PCLOG
cat /home/oracle/scripts/L4UD1/logs/postclonedbl4u_s_$DATE.log >> $LOG


echo "Post Clone Application PDB L4U_S is completed Successfully"
